{
    'name': 'Stotz CRM',
    'category': 'Stotz CRM',
    'description': """ """,
    "version": "18.0",
    'depends': ['base', 'crm'],
    'data': [
        'security/crm_record_rule.xml',
        'views/crm_view.xml'
    ],

    'license': 'LGPL-3',
    "application": True,
}
